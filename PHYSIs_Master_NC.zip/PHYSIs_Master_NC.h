#ifndef PHYSIs_Master_NC_h
#define PHYSIs_Master_NC_h

#include "SoftwareSerial.h"
#include "Arduino.h"


#define ESP_UART_RX 12
#define ESP_UART_TX 13
#define BT_UART_RX 10
#define BT_UART_TX 9

class PHYSIs_WiFi {
private:
	void	writeData(String _data);
	bool	confirmData(String _data);
	void	readBuffer();
	void	reqRepeat();
public:
	PHYSIs_WiFi();
	// User Method
	void	enable();
	void	connectWiFi(String _ssid, String _pwd);
	bool	isWiFiStatus();
	void	disconnectWiFi();
	bool	connectMQTT();
	bool	connectMQTT(String _ip, String _port);
	bool	isMqttStatus();
	void	disconnectMQTT();
	bool	startSubscribe(String _serialNum, String _topic);
	bool	stopSubscribe(String _serialNum, String _topic);
	bool	publish(String _serialNum, String _topic, String _message);
	void	(*subscribeListener)(String, String, String);
	void	(*connectBreakListener)(int);
	void	startReceiveMsg();			// loop -> startReceiveMsg		
	// Manager Method
	void	listen();
	bool	isListening();
};


class PHYSIs_BLE {
public:
	PHYSIs_BLE();
	// User Method
	bool	enable();
	String	sendAT(String _command);
	void	sendMessage(String _msg);	// writeData -> sendMessage
	void	startReceiveMsg();			// loop -> startReceiveMsg
	void	(*messageListener)(String);
	// AT Method
	bool	renew();
	bool	reset();
	bool	setName(String _name);
	String	getName();
	String	getAddress();
	// Manager Method
	void	listen();
	bool	isListening();
private:	
	String	reply();					// public -> private
};
#endif