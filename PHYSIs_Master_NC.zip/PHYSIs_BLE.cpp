#include "PHYSIs_Master_NC.h"
#include "SoftwareSerial.h"

SoftwareSerial bleSerial(BT_UART_RX, BT_UART_TX);

const long RES_TIMEOUT = 1000;

PHYSIs_BLE::PHYSIs_BLE() {

}

/*
	Private Method
*/
String PHYSIs_BLE::reply() {
	String replyData = "";
	bool isValid = true;
	long time = millis() + RES_TIMEOUT;
	while (!bleSerial.available()) {
		if (millis() > time) {
			isValid = false;
			break;
		}
	}
	if (isValid) {
		while (bleSerial.available()) {
			char data = bleSerial.read();
			replyData += data;
			delay(1);
		}
	}
	else {
		Serial.println(F("[Err] - Response Timeout.."));
	}
	return replyData;
}

/*
	User Method
*/
bool PHYSIs_BLE::enable() {
	bleSerial.begin(9600);
	bool connected = false;
	for (int j = 0; j < 3; j++) {
		sendMessage("AT");
		if (reply().startsWith("OK")) {
			connected = true;
			break;
		}
	}

	Serial.print(F("# Enable BLE - "));
	if (connected) {
		Serial.println(F("Connected.."));
	}
	else {
		Serial.println(F("Not Connected..Please Restart"));
	}
	return connected;
}

String PHYSIs_BLE::sendAT(String _command) {
	sendMessage(_command);
	return reply();
}

void PHYSIs_BLE::sendMessage(String data) {
	listen();
	bleSerial.print(data);
}

String bleData = "";
void PHYSIs_BLE::startReceiveMsg() {
	while (bleSerial.available()) {
		char data = bleSerial.read();
		bleData += data;
		delay(1);
	}

	if (bleData.length() != 0) {
		messageListener(bleData);
		bleData = "";
	}
}

/*
	AT Method
*/
bool PHYSIs_BLE::renew() {
	sendMessage("AT+RENEW");
	return reply().startsWith("OK");
}

bool PHYSIs_BLE::reset() {
	sendMessage("AT+RESET");
	return reply().startsWith("OK");
}

bool PHYSIs_BLE::setName(String name) {
	String reqData = "AT+NAME" + name;
	sendMessage(reqData);
	if (!reply().startsWith("OK")) {
		return false;
	}
	return reset();
}

String PHYSIs_BLE::getName() {
	sendMessage("AT+NAME?");
	String data = reply();
	int sepIndex = data.indexOf(":");
	return data.substring(sepIndex + 1, data.length());
}

String PHYSIs_BLE::getAddress() {
	sendMessage("AT+ADDR?");
	String data = reply();
	int sepIndex = data.indexOf(":");
	return data.substring(sepIndex + 1, data.length());
}

/*
	Manager Method
*/
void PHYSIs_BLE::listen() {
	if (!bleSerial.isListening()) {
		bleSerial.listen();
	}
}

bool PHYSIs_BLE::isListening() {
	return bleSerial.isListening();
}