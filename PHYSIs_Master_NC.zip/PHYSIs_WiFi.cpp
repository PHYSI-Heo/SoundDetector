#include "PHYSIs_Master_NC.h"
#include "SoftwareSerial.h"

const String ERR_FORMAT = "E0";
const String REQ_REPEAT = "E1";
const String CONN_ERR_WIFI = "E2";
const String CONN_ERR_MQTT = "E3";

const int BREAK_WIFI = 11;
const int BREAK_MQTT = 12;

const String PHYSI_MQTT_IP = "physicomtech.com";
const String PHYSI_MQTT_PORT = "1883";

SoftwareSerial espSerial(ESP_UART_RX, ESP_UART_TX);

String reqData = "";
String validData = "";
bool wifiConnected = false;
bool mqttConnected = false;

PHYSIs_WiFi::PHYSIs_WiFi() {

}

/*
	Public Methods..
*/
void PHYSIs_WiFi::enable() {
	Serial.println(F("# Enable - WiFi"));
	espSerial.begin(115200);
}

void PHYSIs_WiFi::listen() {
	if (!espSerial.isListening()) {		
		espSerial.listen();
	}
}

bool PHYSIs_WiFi::isListening() {
	return espSerial.isListening();
}

void PHYSIs_WiFi::connectWiFi(String ssid, String pwd) {
	wifiConnected = false;
	String data = "W1" + ssid + "," + pwd;
	writeData(data);	
}

bool PHYSIs_WiFi::isWiFiStatus() {
	writeData("W2");
	readBuffer();
	return wifiConnected = validData.endsWith("W21");
}

void PHYSIs_WiFi::disconnectWiFi() {
	wifiConnected = false;
	writeData("W3");
}

bool PHYSIs_WiFi::connectMQTT() {
	if (!wifiConnected) {
		Serial.println(F("[Err] - WiFi is not connected."));
		return false;
	}
	mqttConnected = false;
	String data = "M1" + PHYSI_MQTT_IP + "," + PHYSI_MQTT_PORT;
	writeData(data);
	readBuffer();
	return mqttConnected = validData.endsWith("M21");
}

bool PHYSIs_WiFi::connectMQTT(String ip, String port) {
	if (!wifiConnected) {
		Serial.println(F("[Err] - WiFi is not connected."));
		return false;
	}
	mqttConnected = false;
	String data = "M1" + ip + "," + port;
	writeData(data); 
	readBuffer();
	return mqttConnected = validData.endsWith("M21");
}

bool PHYSIs_WiFi::isMqttStatus() {
	writeData("M2");
	readBuffer();
	return mqttConnected = validData.endsWith("M21");
}

void PHYSIs_WiFi::disconnectMQTT() {
	mqttConnected = false;
	writeData("M3");
}

bool PHYSIs_WiFi::startSubscribe(String _serialNum, String topic) {
	if (!wifiConnected) {
		Serial.println(F("[Err] - WiFi is not connected."));
		return false;
	}

	if (!mqttConnected) {
		Serial.println(F("[Err] - MQTT is not connected."));
		return false;
	}

	String data = "M5" + _serialNum + "/" + topic;
	writeData(data);
	readBuffer();
	return validData.endsWith("M51");
}

bool PHYSIs_WiFi::stopSubscribe(String _serialNum, String topic) {
	if (!wifiConnected) {
		Serial.println(F("[Err] - WiFi is not connected."));
		return false;
	}

	if (!mqttConnected) {
		Serial.println(F("[Err] - MQTT is not connected."));
		return false;
	}

	String data = "M6" + _serialNum + "/" + topic;
	writeData(data);
	readBuffer();
	return validData.endsWith("M61");
}

bool PHYSIs_WiFi::publish(String _serialNum, String topic, String msg) {
	if (!wifiConnected) {
		Serial.println(F("[Err] - WiFi is not connected."));
		return false;
	}

	if (!mqttConnected) {
		Serial.println(F("[Err] - MQTT is not connected."));
		return false;
	}

	String data = "M4" + _serialNum + "/" + topic + "," + msg;
	writeData(data);
	readBuffer();
	return validData.endsWith("M41");
}



const String REQ_MQTT_SUB_LISTEN = "M7";
String espData = "";
void PHYSIs_WiFi::startReceiveMsg() {
	while (espSerial.available()) {
		char readByte = espSerial.read();
		espData += readByte;
		delay(1);
	}

	if (espData.length() != 0) {
		if (confirmData(espData)) {
			if (validData.startsWith(REQ_MQTT_SUB_LISTEN)) {
				int sepIndex = validData.indexOf(",");
				int topicIndex = validData.indexOf("/");
				subscribeListener(validData.substring(2, topicIndex),
					validData.substring(topicIndex + 1, sepIndex),
					validData.substring(sepIndex + 1, validData.length()));
			}
			else if (validData.equals(REQ_REPEAT)) {
				//Serial.println(F("[Recv] - Request Repeat.."));
				espSerial.print(reqData);
			}
			else if (validData.equals(CONN_ERR_WIFI)) {
				Serial.println(F("[Err] - Break WiFi.."));
				connectBreakListener(BREAK_WIFI);
			}
			else if (validData.equals(CONN_ERR_MQTT)) {
				Serial.println(F("[Err] - Break MQTT.."));
				connectBreakListener(BREAK_MQTT);
			}

		}
		else {
			//Serial.println(F("[Err] - Receive Format.."));
			reqRepeat();
		}
		espData = "";
	}
}


/*
	Private Methods..
*/
void PHYSIs_WiFi::writeData(String data) {
	listen();
	int checkSum = 0;
	for (int i = 0; i < data.length(); i++) {
		checkSum += data[i];
	}
	reqData = "$" + String(checkSum) + "," + data + "#";

	//Serial.print(F("# Write Data : "));
	//Serial.println(reqData);
	delay(100);
	espSerial.print(reqData);
}

void PHYSIs_WiFi::reqRepeat() {	
	listen();
	int checkSum = 0;
	for (int i = 0; i < ERR_FORMAT.length(); i++) {
		checkSum += ERR_FORMAT[i];
	}
	String repeat = reqData = "$" + String(checkSum) + "," + ERR_FORMAT + "#";
	espSerial.print(repeat);
}

bool PHYSIs_WiFi::confirmData(String data) {
	validData = "";
	int sepIndex = data.indexOf(",");
	if (!data.startsWith("$") || !data.endsWith("#") || sepIndex == -1)
		return false;

	int checkSum = 0;
	validData = data.substring(sepIndex + 1, data.length() - 1);
	for (int i = 0; i < validData.length(); i++) {
		checkSum += validData[i];
	}
	return data.substring(1, sepIndex).toInt() == checkSum;
}


void PHYSIs_WiFi::readBuffer() {
	String readData = "";
	bool isValid = true;
	long time = millis() + 10000;

	while (!espSerial.available()) {
		if (millis() > time) {
			isValid = false;
			break;
		}
	}

	if (isValid) {
		while (espSerial.available()) {
			char readByte = espSerial.read();
			readData += readByte;
			delay(1);
		}

		if (readData.length() != 0) {
			//Serial.print(F(">> Read Data : "));
			//Serial.println(readData);
			if (confirmData(readData)) {
				if (validData.equals(REQ_REPEAT)) {
					//Serial.println(F("[Recv] - Request Repeat.."));
					espSerial.print(reqData);
					readBuffer();
				}
			}
			else {
				//Serial.println(F("[Err] - Receive Format.."));
				reqRepeat();
				readBuffer();
			}
		}

	}
	else {
		Serial.println(F("[Err] - Receive Timeout.."));
	}
}
